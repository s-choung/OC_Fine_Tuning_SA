# File Pairs

## .dat Files

- 0.dat - /home1/jsh9967/15_for_fun_mace/1_bulk
- 1.dat - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/2_cal
- 2.dat - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/3_vac/1
- 3.dat - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/3_vac/2
- 4.dat - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/3_vac/3
- 5.dat - /home1/jsh9967/15_for_fun_mace/2_surf/2_100/1_cal
- 6.dat - /home1/jsh9967/15_for_fun_mace/2_surf/2_100/2_vac/1
- 7.dat - /home1/jsh9967/15_for_fun_mace/2_surf/3_110/1_cal
- 8.dat - /home1/jsh9967/15_for_fun_mace/2_surf/3_110/2_vac
- 9.dat - /home1/jsh9967/15_for_fun_mace/2_surf/4_221/1_cal
- 10.dat - /home1/jsh9967/15_for_fun_mace/2_surf/4_221/2_vac/1
- 11.dat - /home1/jsh9967/15_for_fun_mace/2_surf/4_221/2_vac/2
- 12.dat - /home1/jsh9967/15_for_fun_mace/2_surf/5_210/1_cal
- 13.dat - /home1/jsh9967/15_for_fun_mace/2_surf/5_210/2_vac/1
- 14.dat - /home1/jsh9967/15_for_fun_mace/2_surf/5_210/2_vac/2

## XDATCAR Files

- 0_XDATCAR - /home1/jsh9967/15_for_fun_mace/1_bulk
- 1_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/2_cal
- 2_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/3_vac/1
- 3_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/3_vac/2
- 4_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/3_vac/3
- 5_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/2_100/1_cal
- 6_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/2_100/2_vac/1
- 7_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/3_110/1_cal
- 8_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/3_110/2_vac
- 9_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/4_221/1_cal
- 10_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/4_221/2_vac/1
- 11_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/4_221/2_vac/2
- 12_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/5_210/1_cal
- 13_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/5_210/2_vac/1
- 14_XDATCAR - /home1/jsh9967/15_for_fun_mace/2_surf/5_210/2_vac/2

## CONTCAR Files

- 0_CONTCAR - /home1/jsh9967/15_for_fun_mace/1_bulk
- 1_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/2_cal
- 2_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/3_vac/1
- 3_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/3_vac/2
- 4_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/1_111/3_vac/3
- 5_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/2_100/1_cal
- 6_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/2_100/2_vac/1
- 7_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/3_110/1_cal
- 8_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/3_110/2_vac
- 9_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/4_221/1_cal
- 10_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/4_221/2_vac/1
- 11_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/4_221/2_vac/2
- 12_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/5_210/1_cal
- 13_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/5_210/2_vac/1
- 14_CONTCAR - /home1/jsh9967/15_for_fun_mace/2_surf/5_210/2_vac/2
